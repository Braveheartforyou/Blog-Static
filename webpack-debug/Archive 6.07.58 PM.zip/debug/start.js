/*
 * @Descripttion: 
 * @Author: 19080088
 * @Date: 2021-03-11 11:36:00
 * @LastEditors: 19080088
 * @LastEditTime: 2021-03-11 16:49:34
 */
const webpack = require('../lib/index.js')  // 直接使用源码中的webpack函数
const config = require('./webpack.config')
const compiler = webpack(config)
compiler.run((err, stats)=>{
    if(err){
        console.error(err)
    }else{
        console.log(stats)
    }
})