/*
 * @Descripttion: 
 * @Author: 19080088
 * @Date: 2021-03-11 11:24:39
 * @LastEditors: 19080088
 * @LastEditTime: 2021-03-11 11:35:11
 */
const path = require('path')
module.exports = {
    context: __dirname,
    mode: 'development',
    devtool: 'source-map',
    entry: './src/index.js',
    output: {
        path: path.join(__dirname, './dist'),
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                use: ['babel-loader'],
                exclude: /node_modules/,
            }
        ]
    }
}