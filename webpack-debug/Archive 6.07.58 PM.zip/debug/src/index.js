/*
 * @Descripttion: 
 * @Author: 19080088
 * @Date: 2021-03-11 11:41:11
 * @LastEditors: 19080088
 * @LastEditTime: 2021-03-11 11:50:14
 */
import is from 'object.is'  // 这里引入一个小而美的第三方库，以此观察webpack如何处理第三方包
console.log('很高兴认识你，webpack')
console.log(is(1,1))